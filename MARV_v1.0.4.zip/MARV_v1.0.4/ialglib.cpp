/********************************************************************
Stub file for assembly optimized ALGLIB subroutines.
********************************************************************/

#include "stdafx.h"
#include "ialglib.h"

