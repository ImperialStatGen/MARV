/*************************************************************************
 MARV software:  Jan, 2017

 Contributors:
 * Marika Kaakinen
 * Reedik M�gi
 * Krista Fischer
 * Andrew P Morris
 * Inga Prokopenko

Copyright (c) 2017, Imperial College London
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*************************************************************************/

#include "sample.h"
#include <string>
#include <vector>
sample::sample(std::string name)
{
	 _name = name;

}

sample::~sample(void)
{
}

std::string
sample::getName()
{
	return _name;
}
void
sample::addPheno(double pheno)
{
	_phenos.push_back(pheno);
}
double
sample::getPheno(unsigned int i)
{
	if (_phenos.size()<=i) return -9999;
	return _phenos[i];
}
unsigned long
sample::getPhenoCount()
{
	return _phenos.size();
}
double
sample::setPheno(unsigned int i, double pheno)
{
	_phenos[i]=pheno;
}

/*void
sample::addCovariate(double covariate)
{
	_covariates.push_back(covariate);
}

double
sample::getCovariate(unsigned int i)
{
	if (_covariates.size()<=i) return -9999;
	return _covariates[i];
}

unsigned long
sample::getCovariateCount()
{
	return _covariates.size();
}
*/
bool
sample::isOK()
{

	for (unsigned int i = 0; i < _phenos.size(); i++)
	{
		if (_phenos[i] == -9999) return false;
	}
	return true;
}


