/*************************************************************************
 MARV software:  Jan, 2017

 Contributors:
 * Marika Kaakinen
 * Reedik M�gi
 * Krista Fischer
 * Andrew P Morris
 * Inga Prokopenko

Copyright (c) 2017, Imperial College London
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*************************************************************************/
#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <fstream>
#include <cctype>
#include <map>
#include <zlib.h>
#include "global.h"
#include "CmdLine.h"
#include "tools.h"
#include "sample.h"
#include "marker.h"
#include "structures.h"
#include "regression.h"
#include "studenttdistr.h"
#include "chisquaredistr.h"

#define LENS 1000000

using namespace TCLAP;
using namespace std;

double dabs(double x){if (x>0) return x; return x*-1.0;}
double ddabs(double d){if(d<0)return d*-1;return d;}


class gene{
public:
    std::string name;
    vector<marker> M;
    int chr;
    int start;
    int end;
};

bool readSampleData(global & G, vector <sample> & S, ofstream & LOG, ofstream & ERR);
bool readExclusionSampleData(global & G, vector <sample> & S,  ofstream & LOG, ofstream & ERR);
bool readExtractSampleData(global & G, vector <sample> & S,  ofstream & LOG, ofstream & ERR);
bool readMapData(global & G, vector <gene> & GENE, ofstream & LOG, ofstream & ERR);
bool readExclusionMarkersData(global & G, vector <sample> & S,  ofstream & LOG, ofstream & ERR);
bool readExtractMarkersData(global & G, vector <sample> & S,  ofstream & LOG, ofstream & ERR);
bool readGenotypeData(global & G, vector <sample> & S,  vector <gene> & GENE,  ofstream & LOG, ofstream & ERR, ofstream & OUT, ofstream & BETAS);
void Analyse(global & G, vector <sample> & S, gene & GENE_p, ofstream & LOG, ofstream & ERR, ofstream & OUT, ofstream & BETAS);


int Tokenize(const  string& str1, vector<string>& tokens, const string& delimiters = " ");

int main(int argc, char *argv[])
{
    global GLOBAL;
    vector <marker> M;
	vector <sample> S;
	vector <gene> GENE;

try {
        CmdLine cmd("For more info: http://www.websiteformarv.com/MARV/", ' ', GLOBAL.version );

        //
        // Define arguments read from the command line using CmdLine.h
        // Reads in what user inputs
        //
        vector<string> methods_allowed;
        methods_allowed.push_back("threshold");
        methods_allowed.push_back("expected");
        ValuesConstraint<string> allowedVals( methods_allowed );

        ValueArg<string> samplefArg("s","sample","This specifies sample file",true,"","string", cmd);
        ValueArg<string> genofArg("g","gen","This specifies genotype file",true,"","string", cmd);
        ValueArg<string> chrArg("","chr","All markers in genotype file are forced to be from this chromosome. Ignoring the first column in genotype file",false,"","string", cmd);
        ValueArg<string> outfArg("o","out","This specifies output files root",false,"granvil","string", cmd);
        ValueArg<string> mapfArg("x","genmap","This specifies gene map file",true,"","string", cmd);
        ValueArg<string> methodArg("m","method","This option controls how the genotype uncertainty is taken into account",true,"threshold",&allowedVals, cmd);
        ValueArg<string> s_ex_fArg("","exclude_samples","This specifies file with excluded samples",false,"","string", cmd);
        ValueArg<string> m_ex_fArg("","exclude_markers","This specifies file with excluded markers",false,"","string", cmd);
        ValueArg<string> s_in_fArg("","extract_samples","This specifies file with extracted samples",false,"","string", cmd);
        ValueArg<string> m_in_fArg("","extract_markers","This specifies file with extracted markers",false,"","string", cmd);
        ValueArg<string> naArg("","missing_code","This specifies the coding for missing data (default NA)",false,"NA","double", cmd);
        ValueArg<double> imp_thresh_Arg("", "imp_thresh", "Imputation score threshold for including markers (default 0.4)", false, 0.4,"double" , cmd);
        ValueArg<double> call_thresh_Arg("", "call_thresh", "Call-rate threshold for the best guess genotypes (default 0.9)", false, 0.9,"double" , cmd);
        ValueArg<double> rare_thresh_Arg("r", "rare_thresh", "Minor allele cut-off for defining rare variants (default 0.05)", false, 0.05,"double" , cmd);
        ValueArg<double> flankingArg("f","flanking","This specifies flanking region size in kb (default 0 kb)",false,0.0,"double", cmd);

        //MultiArg<string> covnamesArg("","cov_name", "Name of covariate to use (in case of several covariates, use this command multiple times i.e. --cov_name SEX --cov_name AGE etc.)", false, "string", cmd);
        //SwitchArg covallArg("", "cov_all","All covariates are used in analysis", cmd);
        MultiArg<string> phenoNamesArg("","pheno_name", "Name of phenotype to use (use this command multiple times i.e. --pheno_name BMI --pheno_name HEIGHT etc.)", true, "string", cmd);
        SwitchArg rmmissingArg("", "remove_missing","Remove sample if any of the phenotype values is missing (default OFF)", cmd);
        SwitchArg printallArg("", "print_all","Print results for all models (default OFF)", cmd);
        SwitchArg printBetas("", "betas","Print effect size and stderr info (default OFF)", cmd);
        SwitchArg printComplexArg("", "print_complex","Print only the model with all phenotypes (default OFF)", cmd);
        SwitchArg printCovarianceArg("", "print_covariance","Print covariance matrix data for the model with all phenotypes (default OFF)", cmd);

        SwitchArg debugArg("", "debug","Debug mode enabled", cmd);

        cmd.parse(argc,argv);

        GLOBAL.inputSampleFile = samplefArg.getValue();
        GLOBAL.inputGenFile = genofArg.getValue();
        if (chrArg.getValue() == "") GLOBAL.chromosome=0;
        else
        {
            if (uc(chrArg.getValue())=="MT"){GLOBAL.chromosome=26;}
            else if (uc(chrArg.getValue())=="XY"){GLOBAL.chromosome=25;}
            else if (uc(chrArg.getValue())=="Y"){GLOBAL.chromosome=24;}
            else if (uc(chrArg.getValue())=="X"){GLOBAL.chromosome=23;}
            else if (atoi(chrArg.getValue().c_str())>0 && atoi(chrArg.getValue().c_str())< 27){GLOBAL.chromosome = atoi(chrArg.getValue().c_str());}
            else
            {
                cerr << "Unreadable chromosome number. Please use either numbers between 1-26 or X,Y,XY,MT"<<endl;
                exit(1);

            }
        }
        GLOBAL.outputRoot = outfArg.getValue();
        GLOBAL.outputError = outfArg.getValue() + ".err";
        GLOBAL.outputLog = outfArg.getValue() + ".log";
        GLOBAL.outputResult = outfArg.getValue() + ".result";
        GLOBAL.outputBetas = outfArg.getValue() + ".betas";
        GLOBAL.inputMapFile = mapfArg.getValue();
        if (uc(methodArg.getValue())=="THRESHOLD") GLOBAL.method=0;
        else {GLOBAL.method=1;GLOBAL.dosages=1;}
        GLOBAL.inputExclusionSamplesFile = s_ex_fArg.getValue();
        GLOBAL.inputExclusionMarkersFile = m_ex_fArg.getValue();
        GLOBAL.inputExtractSamplesFile = s_in_fArg.getValue();
        GLOBAL.inputExtractMarkersFile = m_in_fArg.getValue();
        if (naArg.getValue()!="") GLOBAL.missingCode = naArg.getValue();
        else GLOBAL.missingCode = "NA";
        GLOBAL.infoThreshold = imp_thresh_Arg.getValue();
        GLOBAL.callrateThreshold = call_thresh_Arg.getValue();
        GLOBAL.rareVariantThreshold = rare_thresh_Arg.getValue();
        GLOBAL.flanking = flankingArg.getValue();

        //GLOBAL.covList = covnamesArg.getValue();
        //GLOBAL.covCount = (int)GLOBAL.covList.size();
        //GLOBAL.cov_all = covallArg.getValue();
        GLOBAL.phenoList = phenoNamesArg.getValue();
        GLOBAL.removeMissing = rmmissingArg.getValue();
        GLOBAL.printAll = printallArg.getValue();
        GLOBAL.printBetas = printBetas.getValue();
        GLOBAL.printComplex = printComplexArg.getValue();
        GLOBAL.printCovariance = printCovarianceArg.getValue();

        GLOBAL.debugMode = debugArg.getValue();

        if (GLOBAL.phenoList.size()<2)
        {
            cout<< "Less than 2 phenotypes selected for the analysis. Please add additional phenotypes for pleiotropy testing. Exit program!" <<endl;
            exit(1);
        }

    GLOBAL.createOutput();
	ofstream ERR (GLOBAL.outputError.c_str());
	ofstream LOG (GLOBAL.outputLog.c_str());



    string v; double len =17 -  GLOBAL.version.size()-1;
	int f = (int) ((len/2.0)+0.6); 	int r = (int) ((len/2.0));	for (int i=0; i < f;i++)v+=" ";
	v+='v';	v+=GLOBAL.version; for (int i=0; i < r;i++)v+=" ";

	LOG << endl;
	LOG << "@----------------------------------------------------------@" << endl;
	LOG << "|     MARV        |" << v << "|  January, 2017  |" << endl;
	LOG << "|----------------------------------------------------------|" << endl;
	LOG << "|           (C) 2017 MARV TEAM                             |" << endl;
	LOG << "|               The BSD 3-Clause License                   |" << endl;
	LOG << "|----------------------------------------------------------|" << endl;
	LOG << "|   MARV - Multi-phenotype Analysis of Rare Variants       |" << endl;
	LOG << "|                                                          |" << endl;
	LOG << "|                                                          |" << endl;
	LOG << "|  For documentation, citation & bug-report instructions:  |" << endl;
	LOG << "|         http://github.com/statgenimperial/marv           |" << endl;
	LOG << "@----------------------------------------------------------@" << endl;
	LOG << endl;
	LOG << "Using following command line options:" << endl;
	LOG << "Sample file: " << GLOBAL.inputSampleFile << endl;
	LOG << "Genotype file: " << GLOBAL.inputGenFile << endl;
	LOG << "Gene map file: " << GLOBAL.inputMapFile << endl;

	if (GLOBAL.inputExclusionMarkersFile.compare("")!=0)LOG << "Marker exclusion file: " << GLOBAL.inputExclusionMarkersFile << endl;
	if (GLOBAL.inputExtractMarkersFile.compare("")!=0)LOG << "Markers inclusion file: " << GLOBAL.inputExtractMarkersFile << endl;
	if (GLOBAL.inputExclusionSamplesFile.compare("")!=0)LOG << "Sample exclusion file: " << GLOBAL.inputExclusionSamplesFile << endl;
	if (GLOBAL.inputExtractSamplesFile.compare("")!=0)LOG << "Sample inclusion file: " << GLOBAL.inputExtractSamplesFile << endl;
    LOG << "Phenotypes: ";
    for (int i=0; i<GLOBAL.phenoList.size(); i++){LOG << GLOBAL.phenoList[i] << " ";}
    LOG << "(" << GLOBAL.phenoList.size() << ")" << endl;
    /*if (GLOBAL.cov_all) LOG << "Using all covariates from sample file (cov_all)" << endl;
	else if (GLOBAL.covCount>-1)
    {LOG << "Covariates: ";
        for (int i = 0; i<GLOBAL.covCount; i++){LOG << GLOBAL.covList[i] << " ";}
        LOG << "(" << GLOBAL.covCount << ")" << endl;

    }*/
    if (GLOBAL.removeMissing) {LOG << "Remove samples with any missing phenotype data (remove_missing ON)"<<endl;}
    else {LOG << "Use all available phenotype data (remove_missing OFF)"<<endl;}
    LOG << "Output result file: " << GLOBAL.outputResult << endl;
    LOG << "Output log file: " << GLOBAL.outputLog << endl;
    LOG << "Output betas file: " << GLOBAL.outputBetas << endl;
	if (GLOBAL.printCovariance && GLOBAL.printComplex)
        {
            LOG << "Print covariance matrix (print_covariance ON)"<<endl;
        }
        else if (GLOBAL.printCovariance && !GLOBAL.printComplex)
        {
            cout << "printCovariance option is only available, if printComplex is used. Exit program.";
            exit(1);
        }
        if (GLOBAL.printAll) {LOG << "Print all possible models (print_all ON)"<<endl;}
        else if (GLOBAL.printComplex){LOG << "Print only the model with all phenotypes (print_complex ON)"<<endl;}
        else {LOG << "Print only best model (print_all OFF)"<<endl;}
	if (GLOBAL.printBetas){LOG << "Creating file for saving all beta and stderr values for all phenotypes in all selected models" << endl;}

	if (GLOBAL.method==1) LOG << "Using allele dosages instead of determined genotypes (method=expected)" << endl;
    else{LOG<< "Using certain genotypes (method=threshold)"<<endl;}
    if (GLOBAL.method==1) LOG << "Marker imputation info threshold >= " << GLOBAL.infoThreshold << endl;
    if (GLOBAL.method==0) LOG << "Marker call rate threshold >= " << GLOBAL.callrateThreshold << endl;
    if (GLOBAL.debugMode) LOG << "DEBUG MODE ON"<<endl;

	if (GLOBAL.chromosome>0)LOG << "All markers from chromosome: "<<GLOBAL.chromosome << "(use this option, if first column does not contain chromosome number or you want to use imputed data as well)" << endl;
	LOG << "Marker allele freq. cut-off for determining a rare variant <= " << GLOBAL.rareVariantThreshold << endl;
    LOG << "Missing phenotype data value: " << GLOBAL.missingCode << endl;
    LOG << "Using flanking region size: " << GLOBAL.flanking << " kb"<<endl;


	cout <<"Reading sample file from " <<  GLOBAL.inputSampleFile << endl;
	readSampleData(GLOBAL, S, LOG, ERR);

    if (!GLOBAL.inputExclusionSamplesFile.compare("")==0)		//exclusion list is used
	{
    cout <<"Reading sample exclusion file from " <<  GLOBAL.inputExclusionSamplesFile << endl;
	readExclusionSampleData(GLOBAL, S, LOG, ERR);
	}

    if (!GLOBAL.inputExtractSamplesFile.compare("")==0)		//extraction list is used
	{
    cout <<"Reading sample extraction file from " <<  GLOBAL.inputExtractSamplesFile << endl;
    readExtractSampleData(GLOBAL, S, LOG, ERR);
	}


    if (!GLOBAL.inputExclusionMarkersFile.compare("")==0)		//exclusion list is used
	{
    cout <<"Reading marker exclusion file from " <<  GLOBAL.inputExclusionMarkersFile << endl;
    readExclusionMarkersData(GLOBAL, S, LOG, ERR);
    GLOBAL.markerExclusion=true;
	}

    if (!GLOBAL.inputExtractMarkersFile.compare("")==0)		//extraction list is used
	{
    cout <<"Reading marker extraction file from " <<  GLOBAL.inputExtractMarkersFile << endl;
    readExtractMarkersData(GLOBAL, S, LOG, ERR);
    GLOBAL.markerExtraction=true;
	}

 	cout <<"Reading genemap data from " <<  GLOBAL.inputMapFile << endl;
    readMapData(GLOBAL,GENE, LOG, ERR);


    ofstream OUT (GLOBAL.outputResult.c_str());
    ofstream BETAS (GLOBAL.outputBetas.c_str());
    if (!GLOBAL.printCovariance)

    OUT << "Gene\tRareCount\tN\tRareVariantSum\tTotalMAF\tAverageMAF\tPhenotypeCount\tMask\tLogLikelihood\tnullLogLikelihood\tLikelihoodRatio\tP-value\tBIC\tBICnull\tModel\tsortedModel\n";
    else
    {

        OUT << "Gene\tRareCount\tN\tRareVariantSum\tTotalMAF\tAverageMAF\tPhenotypeCount\tMask\tLogLikelihood\tnullLogLikelihood\tLikelihoodRatio\tP-value\tBIC\tBICnull\tModel\tsortedModel";
        for (int i = 0; i < GLOBAL.phenoList.size();i++) OUT << "\tbeta_" << i+1 << "\tse_" << i+1;
        for (int i = 0; i < GLOBAL.phenoList.size();i++)
        {
            for (int j = i; j < GLOBAL.phenoList.size();j++)
                OUT << "\tcov_" << i+1 << "_" << j+1;
        }
        OUT << endl;
    }
    if (GLOBAL.printBetas){
        BETAS << "Gene\tRareCount\tN\tRareVariantSum\tTotalMAF\tAverageMAF\tModel\tModel_member\tbeta\tse\n";
    }

    cout <<"Reading genotype data from " <<  GLOBAL.inputGenFile << endl;
    readGenotypeData(GLOBAL, S, GENE, LOG, ERR, OUT, BETAS);


    cout << "Analysis finished."<<endl;
    LOG << "Analysis finished."<<endl;

    BETAS.close();
    OUT.close();
	ERR.close();
	LOG.close();

	} catch (ArgException &e)  // catch any exceptions
	{ cerr << "error: " << e.error() << " for arg " << e.argId() << endl; }

    return 0;

}
bool
readSampleData(global & G, vector <sample> & S,  ofstream & LOG, ofstream & ERR)
{
    char sb [10];				//error name char buffer
	int lineNr = 0;
	ifstream F (G.inputSampleFile.c_str());
	if (F.is_open())
    {
		vector <string> phenoColumnNames;
		//vector <string> covColumnNames;
		vector <int> phenoColumns;
		//vector <int> covColumns;

		int okCnt = 0;

       	while (! F.eof() )
        {
	        string line;
        	vector<string> tokens;
        	getline (F,line);
			string currentmarker = "";
			int n = Tokenize(string(line), tokens, " ");		//tabulating file by space

			if (lineNr==0)                                      //get columns from the first row of data
            {
                if (n>2)
                {
                    for (int i = 0; i < n; i++)                     //phenos
                    {
                        for (int j = 0; j<G.phenoList.size(); j++)
                        {
                            if (uc(tokens[i]) == uc(G.phenoList[j]))
                            {
                                phenoColumns.push_back(i);
                                phenoColumnNames.push_back(tokens[i]);
                            }
                        }
                    }
                     /*  for (int i = 0; i < n; i++)                     //covariates
                    {
                        for (int j = 0; j<G.covList.size(); j++)
                        {
                            if (uc(tokens[i]) == uc(G.covList[j]))
                            {
                                covColumns.push_back(i);
                                covColumnNames.push_back(tokens[i]);
                            }
                        }

                    }*/

                }//if(n>2)
                if (G.phenoList.size()!=phenoColumns.size())
                {
                    cout << "One or more phenotypes cannot be found from the sample file. Exit program!\nExpected: ";
                    for (int j = 0; j<G.phenoList.size(); j++){cout << G.phenoList[j] << " ";}
                    cout << "\nFound: ";
                    for (int j = 0; j<phenoColumns.size(); j++){cout << phenoColumnNames[j] << " ";}
                    cout << endl;
                    exit(1);
                }
                else
                {
                    G.phenoList = phenoColumnNames;
                }
            }//if(lineNr==0)
			/*else if (lineNr == 1)
			{
				if (n>2)
				{
					for (int i = 0; i < n; i++)
					{
                            if ((tokens[i][0] == 'C' || tokens[i][0] == 'D') && G.cov_all==true)
                            {
                                covColumns.push_back(i); //cov_all option according to this row
                            }
					}

				}
			}*/
			else if (lineNr>=2) //read in data
			{
				if (n>2)
				{

					string name = string(tokens[0]);
					vector <double> phenos;
					//vector <double> covariates;
					bool _hasMissing=false;
					sample s(name);


                    for (unsigned int i = 0; i < phenoColumns.size(); i++) //phenos
					{
						if (tokens[phenoColumns[i]].c_str()!=G.missingCode)
                        {
                            s.addPheno(atof(tokens[phenoColumns[i]].c_str()));
                        }
						else
                        {
                            s.addPheno(-9999); _hasMissing=true;
                        }
					}
					if (G.removeMissing==true && _hasMissing==true) //replace all with missing if one of them is missing
                    {
                        for (int i = 0; i < phenoColumns.size(); i++){s.setPheno(i,-9999);}
                    }


					/*for (unsigned int i = 0; i < covColumns.size(); i++) //covariates
					{
						if (tokens[covColumns[i]].c_str()!=G.missingCode)
                        {
                            s.addCovariate(atof(tokens[covColumns[i]].c_str()));
                        }
						else s.addCovariate(-9999);
					}*/

					S.push_back(s);

					if (s.isOK())
					{

                        okCnt ++;

                    G.pheno_ok = okCnt;

                    if (G.debugMode)cout << "Pheno_ok" << okCnt << endl;
					}


            }
			}//else if(linNr==2)
			lineNr++;
			}//while (! F.eof() )

		}//if (F.is_open())

	else
	{
		cerr << "Error: Cannot find or access " << G.inputSampleFile << ". Exit program." << endl;
		sprintf(sb, "E%.8d" , G.errNr); G.errNr++;
		LOG << "Error: Cannot find or access " << G.inputSampleFile << ". Exit program! (" << sb << ")" <<endl;
		ERR << sb << " Error: Cannot find or access " << G.inputSampleFile << ". Program exit!" <<endl;
		ERR << sb << " Error: Make sure that the file is in the given path and is readable." <<endl;
		exit(1);
		return false;
	}
    if (G.debugMode)cout << "Altogether: " << G.phenoList.size() << " phenotypes" << endl;
//    if (G.debugMode)cout << "Altogether: " << G.covList.size() << " covariates" << endl;
    if (G.debugMode)cout << "Altogether: " << S.size() << " samples" << endl;
    LOG << "Sample file contained: " << G.phenoList.size() << " phenotypes" << endl;
    //LOG << "Sample file contained: " << G.covList.size() << " covariates" << endl;
    LOG << "Sample file contained: " << S.size() << " samples" << endl;


	return true;

}
bool
readExclusionSampleData(global & G, vector <sample> & S,  ofstream & LOG, ofstream & ERR)
{
	int excludedCount = 0;
	char sb [10];				//error name char buffer
	ifstream F (G.inputExclusionSamplesFile.c_str());
	if (F.is_open())
    {
       	while (! F.eof() )
        {
	        string line;
        	vector<string> tokens;
        	getline (F,line);
			string currentmarker = "";
			int n = Tokenize(string(line), tokens, " ");		//tabulating file by space
			if (n>0)
			{
				string sampleName = string(tokens[0]);
				for (int i = 0; i < S.size(); i++)
				{
					if (sampleName.compare(S[i].getName())==0)
					{

						for (int j = 0; j < G.phenoList.size(); j++)
                        {
                        S[i].setPheno(j,-9999);
                        }

						excludedCount++;
					}
				}

			}
		}
	}
		else
	{
		cerr << "Error: Cannot find or access " << G.inputExclusionSamplesFile << ". Exit program." << endl;
		sprintf(sb, "E%.8d" , G.errNr); G.errNr++;
		LOG << "Error: Cannot find or access " << G.inputExclusionSamplesFile << ". Exit program! (" << sb << ")" <<endl;
		ERR << sb << " Error: Cannot find or access " << G.inputExclusionSamplesFile << ". Program exit!" <<endl;
		ERR << sb << " Error: Make sure that the file is in the given path and is readable." <<endl;
		exit (0);
		return false;
	}
	if (G.debugMode) cout << "Excluded individuals count: " << excludedCount << endl;
	LOG << "Sample exclusion list contained: " << excludedCount << " samples" << endl;

	int okCnt =0;

	for (int i =0; i<S.size(); i++){ //this counts individuals with non-missing data, even those in addition to exclusion list
        if(S[i].isOK()){

            okCnt ++;
        }
    }

    int okCnt2=S.size()-excludedCount;

    if (G.debugMode) cout << "Remaining individuals after exclusion list: " << okCnt2 << endl;
	LOG << "Remaining individuals for analysis after exclusions list: " << okCnt2 << endl;

	if (G.debugMode) cout << "Remaining individuals with non-missing data: " << okCnt << endl;
	LOG << "Remaining individuals for analysis with non-missing data: " << okCnt << endl;
	G.pheno_ok = okCnt;


	return true;
}
bool
readExtractSampleData(global & G, vector <sample> & S,  ofstream & LOG, ofstream & ERR)
{
	int excludedCount = 0;
	char sb [10];				//error name char buffer
    vector<string> sampleNames;
	ifstream F (G.inputExtractSamplesFile.c_str());
	if (F.is_open())
    {
       	while (! F.eof() )
        {
	        string line;
        	vector<string> tokens;
        	getline (F,line);
			string currentmarker = "";
			int n = Tokenize(string(line), tokens, " ");		//tabulating file by space
			if (n>0)
			{
				sampleNames.push_back(string(tokens[0]));
			}
		}
        for (int i = 0; i < S.size(); i++)
        {
            bool sample_is_ok=false;
            for (int j = 0; j<sampleNames.size(); j++)
            {
                if (sampleNames[j].compare(S[i].getName())==0) sample_is_ok=true;

            }
            if (!sample_is_ok)
            {
                for (int j = 0; j < G.phenoList.size(); j++)
                {
                    S[i].setPheno(j,-9999);
                }
                excludedCount++;
            }
        }

	}
	else
	{
		cerr << "Error: Cannot find or access " << G.inputExtractSamplesFile << ". Exit program." << endl;
		sprintf(sb, "E%.8d" , G.errNr); G.errNr++;
		LOG << "Error: Cannot find or access " << G.inputExtractSamplesFile << ". Exit program! (" << sb << ")" <<endl;
		ERR << sb << " Error: Cannot find or access " << G.inputExtractSamplesFile << ". Program exit!" <<endl;
		ERR << sb << " Error: Make sure that the file is in the given path and is readable." <<endl;
		exit (0);
		return false;
	}

	int okCnt =0;

	for (int i =0; i<S.size(); i++){        //count of individuals with non-missing data
        if(S[i].isOK()){

            okCnt ++;
        }
    }

    int okCnt2=S.size()-excludedCount;

    if (G.debugMode) cout << "Sample extraction list contained: " << okCnt2 << " samples" << endl;
	LOG << "Sample extraction list contained: " << okCnt2 << " samples" << endl;

	if (G.debugMode) cout << "Remaining individuals with non-missing data: " << okCnt << endl;
	LOG << "Remaining individuals for analysis with non-missing data: " << okCnt << endl;
	G.pheno_ok = okCnt;



	return true;
}
bool
readMapData(global & G, vector <gene> & GENE,  ofstream & LOG, ofstream & ERR)
{
	char sb [10];				//error name char buffer
	ifstream F (G.inputMapFile.c_str());
	if (F.is_open())
    {
       	while (! F.eof() )
        {
	        string line;
        	vector<string> tokens;
        	getline (F,line);
			string currentmarker = "";
			int n = Tokenize(string(line), tokens, " ");		//tabulating file by space
            if (n>2)
            {
				gene g;
				g.name = string(tokens[0]);
				g.chr = atoi(tokens[1].c_str());
				g.start = atoi(tokens[2].c_str()) - G.flanking;
				g.end = atoi(tokens[3].c_str()) + G.flanking;

                if (G.chromosome == 0 ||
                    G.chromosome==g.chr)
                        GENE.push_back(g);
			}
		}
	}
	else
	{
		cerr << "Error: Cannot find or access " << G.inputMapFile << ". Exit program." << endl;
		sprintf(sb, "E%.8d" , G.errNr); G.errNr++;
		LOG << "Error: Cannot find or access " << G.inputMapFile << ". Exit program! (" << sb << ")" <<endl;
		ERR << sb << " Error: Cannot find or access " << G.inputMapFile << ". Program exit!" <<endl;
		ERR << sb << " Error: Make sure that the file is in the given path and is readable." <<endl;
		return false;
	}
	LOG << "Genomic regions file contained: " << GENE.size() << " regions for this chromosome" << endl;
    LOG << "Analysing only those regions that include rare variants according to the specified MAF threshold."<< endl;

	return true;
}
bool
readExclusionMarkersData(global & G, vector <sample> & S,  ofstream & LOG, ofstream & ERR)
{
	char sb [10];				//error name char buffer
	int lineNr=0;
	ifstream F (G.inputExclusionMarkersFile.c_str());
	if (F.is_open())
    {
       	while (! F.eof() )
        {
	        string line;
        	vector<string> tokens;
        	getline (F,line);
			string currentmarker = "";
			int n = Tokenize(string(line), tokens, " ");		//tabulating file by space
			if (n>0)
			{
                G.excludemarkers[string(tokens[0]) + ":" + string(tokens[3])]= true;
			}
			lineNr++;
		}

	}
	else
	{
		cerr << "Error: Cannot find or access " << G.inputExclusionMarkersFile << ". Exit program." << endl;
		sprintf(sb, "E%.8d" , G.errNr); G.errNr++;
		LOG << "Error: Cannot find or access " << G.inputExclusionMarkersFile << ". Exit program! (" << sb << ")" <<endl;
		ERR << sb << " Error: Cannot find or access " << G.inputExclusionMarkersFile << ". Program exit!" <<endl;
		ERR << sb << " Error: Make sure that this file is in given path and is readable." <<endl;
		return false;
	}

    if (G.debugMode)cout << "Marker exclusion list contained: " << lineNr << " markers" << endl;
    LOG << "Marker exclusion list contained: " << lineNr << " markers" << endl;
	return true;
}
bool
readExtractMarkersData(global & G, vector <sample> & S,  ofstream & LOG, ofstream & ERR)
{
	char sb [10];				//error name char buffer
	int lineNr=0;
	ifstream F (G.inputExtractMarkersFile.c_str());
	if (F.is_open())
    {
       	while (! F.eof() )
        {
	        string line;
        	vector<string> tokens;
        	getline (F,line);
			string currentmarker = "";
			int n = Tokenize(string(line), tokens, " ");		//tabulating file by space
			if (n>0)
			{
				G.extractmarkers[string(tokens[0]) + ":" + string(tokens[3])]= true;
			}
			lineNr++;
		}

	}
	else
	{
		cerr << "Error: Cannot find or access " << G.inputExtractMarkersFile << ". Exit program." << endl;
		sprintf(sb, "E%.8d" , G.errNr); G.errNr++;
		LOG << "Error: Cannot find or access " << G.inputExtractMarkersFile << ". Exit program! (" << sb << ")" <<endl;
		ERR << sb << " Error: Cannot find or access " << G.inputExtractMarkersFile << ". Program exit!" <<endl;
		ERR << sb << " Error: Make sure that this file is in given path and is readable." <<endl;
		return false;
	}

    if (G.debugMode)cout << "Marker extraction list contained: " << lineNr << " markers" << endl;
    LOG << "Marker extraction list contained: " << lineNr << " markers" << endl;
	return true;
}

bool
readGenotypeData(global & G, vector <sample> & S,  vector <gene> & GENE,  ofstream & LOG, ofstream & ERR, ofstream & OUT, ofstream & BETAS)
{
	char sb [10];				//error name char buffer
	int m_ok = 0;
	int m_notok=0;
	int forcedChromosome = G.chromosome; // forcing all markers from the input file to be be from predefined chromosome - snptest has "---" in first column for imputed snps instead of chromosome number

if(G.inputGenFile.substr(G.inputGenFile.length()-2)=="gz")
    {

        gzFile F =gzopen(G.inputGenFile.c_str(),"r");
        char *buffer = new char[LENS];
          while(0!=gzgets(F,buffer,LENS))
            {
                string line;
                vector<string> tokens;
                string currentmarker = "";
                int n = Tokenize(buffer, tokens, " ");		//tabulating file by space
		if (n>2)
                {
                    int chr;
                    if (uc(tokens[0])=="MT") chr=26;
                    else if (uc(tokens[0])=="XY") chr=25;
                    else if (uc(tokens[0])=="Y") chr=24;
                    else if (uc(tokens[0])=="X") chr=23;
                    else chr = atoi(tokens[0].c_str());

                    if (G.debugMode) cout << "Chromosome id: " << chr;

                    if (forcedChromosome)
                    {
                        chr = forcedChromosome;
                        if (G.debugMode) cout << "Chromosome forced: " << chr;
                    }
                    int pos = atoi(tokens[2].c_str());
                    string markerName = string(tokens[1]);
                    char effectAllele = tokens[3][0];
                    char nonEffectAllele = tokens[4][0];
                    if (G.debugMode) cout << "Pos: " << pos << "\nmarker:" << markerName << "\nea/nea:" << effectAllele <<"/" << nonEffectAllele<<"\n";

                    vector <double> gen;
                    vector <double> gen2;
                    double fijeij = 0;                 //for info score
                    double aa=0; double aA=0; double AA=0;
                    double callrate=0; double ok_gen=0; double not_ok_gen=0;
                    double infoscore = 1;
                    int j = 0;
                    for (int i = 5; i < n; i+=3)
                    {
                        //determined
                        if(G.dosages==false)
                        {
                            if (S[j].isOK())
                            {
                                if (atof(tokens[i].c_str())>=.95){aa++;}
                                else if (atof(tokens[i+1].c_str())>=.95){aA++;}
                                else if (atof(tokens[i+2].c_str())>=.95){AA++;}
                            }
                            if (atof(tokens[i].c_str())>=.95){gen.push_back(2.0);ok_gen++;}
                            else if (atof(tokens[i+1].c_str())>=.95){gen.push_back(1.0);ok_gen++;}
                            else if (atof(tokens[i+2].c_str())>=.95){gen.push_back(0.0);ok_gen++;}
                            else {gen.push_back(-9999);not_ok_gen++;}
                        }
                        else
                        {
                            if (S[j].isOK())
                            {
                                aa+=atof(tokens[i].c_str());
                                aA+=atof(tokens[i+1].c_str());
                                AA+=atof(tokens[i+2].c_str());
                                double eij=(2*atof(tokens[i+2].c_str())) + atof(tokens[i+1].c_str());
                                double fij = (4*atof(tokens[i+2].c_str())) + atof(tokens[i+1].c_str());
                                fijeij+= fij - (eij*eij);
                            }
                            gen2.push_back(((atof(tokens[i+2].c_str())) + atof(tokens[i+1].c_str())));
                            gen.push_back(((atof(tokens[i].c_str())) + atof(tokens[i+1].c_str())));
                        }
                        if (n < i+5) i+=3;		//avoiding space in line end

                        j++;

                        //test if sample sizes match in genotype and sample file
                        int samplefile_n= (n -5)/3;
                        if (samplefile_n!=S.size())
                        {
                            cout << "The number of samples in genotype file (" << samplefile_n << ") does not match the number of samples in sample file (" << S.size() << "). Exit program!"<<endl;
                            exit (1);
                        }



                    }
                    if (G.debugMode)cout<<"aa,aA,AA"<< aa<<","<<aA<<","<<AA<<"\n";
                    if (G.dosages)
                    {
                        callrate=1;
                        double eaf = 0;
                        if (aa+aA+AA>0)
                        {
                            eaf = ((2*aa)+aA)/(2*(aa+aA+AA));

                        }
                        if (eaf==1 || eaf==0){infoscore=1;}
                        //info score calculation according to the measure in snptest:
                        //https://mathgen.stats.ox.ac.uk/genetics_software/snptest/snptest.v2.pdf
                        else
                        {
                            infoscore = 1-(fijeij/(2*(aa+aA+AA)*eaf*(1-eaf)));
                        }
                        if (G.debugMode)cout<<"N: " << n << " eaf: " << eaf << " aa+aA+AA: " << aa+aA+AA << " Infoscore: "<< infoscore<<endl;

                    }
                    else
                    {
                        callrate = ok_gen/(ok_gen+not_ok_gen);
                        if (G.debugMode)cout<<"Callrate: "<< callrate <<endl;
                    }

                    std::stringstream mrk2;
                    mrk2 << chr << ":" << pos;
                    string mrkname = mrk2.str();

                    bool markerExclusionInclusionIsOK=true;

                    if (G.markerExclusion)
                    {
                        if (G.excludemarkers[mrkname]){markerExclusionInclusionIsOK=false;}
                    }
                    if (G.markerExtraction)
                    {
                        if (!G.extractmarkers[mrkname]){markerExclusionInclusionIsOK=false;}
                    }

                    if (aa+aA+AA>0 && markerExclusionInclusionIsOK)
                    {
                        if (((2*aa)+aA)/(2*(aa+aA+AA))<=0.5)
                        {
                            marker m(markerName, effectAllele, nonEffectAllele, gen);
                            m.setMaf(((2*aa)+aA)/(2*(aa+aA+AA)));
                            if (pos>0 && chr>0 && chr<27 && G.rareVariantThreshold>=m.getMaf() && G.callrateThreshold<=callrate && G.infoThreshold<=infoscore && m.getMaf()>0)
                            {
                                m.setChromosome(chr);
                                m.setPosition(pos);
                                for (int zz=0; zz<GENE.size(); zz++)
                                {
                                    if (chr == GENE[zz].chr &&
                                        pos>= GENE[zz].start &&
                                        pos<=  GENE[zz].end)
                                    {
                                        GENE[zz].M.push_back(m);
                                    }
                                    else if (chr == GENE[zz].chr && pos>GENE[zz].end && GENE[zz].M.size()>0)
                                    {
                                        //LOG << "Analysing genomic region " << GENE[zz].name << " out of the total of " << GENE.size() << " regions." <<endl;
                                        LOG << "Analysing genomic region " << zz+1 << " out of the total of " << GENE.size() << " regions." <<endl;
                                        Analyse(G, S, GENE[zz], LOG, ERR, OUT, BETAS);
                                        GENE[zz].M.clear();
                                    }
                                }
                                m_ok++;

                                if (G.debugMode)cout<<"Marker added to array with maf: "<< ((2*aa)+aA)/(2*(aa+aA+AA))<<"\n";
                                if (G.debugMode)cout<<"Rare allele: "<< effectAllele <<"\n";
                            }
                            else
                            {
                                m_notok++;
                                if (G.debugMode)cout<<"Marker not added\n";
                            }
                        }
                        else //i.e. if allele frequency for a>=0.5
                        {
                            for (unsigned int j = 0; j < gen.size(); j++)
                            {
                                if (!G.dosages){if (gen[j]==2){gen[j]=0;} else if (gen[j]==0){gen[j]=2;}}
                                else {gen[j] = gen2[j];}

                            } //turning around
                            marker m(markerName, nonEffectAllele, effectAllele, gen);
                            m.setMaf(((2*AA)+aA)/(2*(aa+aA+AA)));
                            if (pos>0 && chr>0 && chr<27 && G.rareVariantThreshold>=m.getMaf() && G.callrateThreshold<=callrate && G.infoThreshold<=infoscore && m.getMaf()>0)
                            {
                                m.setChromosome(chr);
                                m.setPosition(pos);

                                for (int zz=0; zz<GENE.size(); zz++)
                                {
                                    if (chr == GENE[zz].chr &&
                                        pos>= GENE[zz].start &&
                                        pos<=  GENE[zz].end)
                                    {
                                        GENE[zz].M.push_back(m);
                                    }
                                    else if (chr == GENE[zz].chr && pos>GENE[zz].end && GENE[zz].M.size()>0)
                                    {
                                        LOG << "Analysing genomic region " << zz+1 << " out of the total of " << GENE.size() << " regions." <<endl;
                                        Analyse(G, S, GENE[zz], LOG, ERR, OUT, BETAS);
                                        GENE[zz].M.clear();
                                    }
                                }

                                m_ok++;

                                if (G.debugMode)cout<<"Marker added to array with maf: "<< ((2*AA)+aA)/(2*(aa+aA+AA))<<"\n";
                                if (G.debugMode)cout<<"Rare allele: "<< nonEffectAllele <<"\n";
                            }
                            else
                            {
                                m_notok++;
                                if (G.debugMode)cout<<"Marker not added\n";
                            }
                        }
                    }
                }
            } //while loop
            for (int zz=0; zz<GENE.size(); zz++)
            {
                if (GENE[zz].M.size()>0)
                {
                     LOG << "Analysing genomic region " << zz+1 << " out of the total of " << GENE.size() << " regions." <<endl;
                    Analyse(G, S, GENE[zz], LOG, ERR, OUT, BETAS);
                    GENE[zz].M.clear();
                }
            }

        return true;
    }//if (gz file)

else
    {
        ifstream F (G.inputGenFile.c_str());
        if (F.is_open())
        {
            while (! F.eof() )
            {
                string line;
                vector<string> tokens;
                getline (F,line);
                string currentmarker = "";
                int n = Tokenize(string(line), tokens, " ");		//tabulating file by space
                if (n>2)
                {
                    int chr;
                    if (uc(tokens[0])=="MT") chr=26;
                    else if (uc(tokens[0])=="XY") chr=25;
                    else if (uc(tokens[0])=="Y") chr=24;
                    else if (uc(tokens[0])=="X") chr=23;
                    else chr = atoi(tokens[0].c_str());

                    if (G.debugMode) cout << "Chromosome id: " << chr;

                    if (forcedChromosome)
                    {
                        chr = forcedChromosome;
                        if (G.debugMode) cout << "Chromosome forced: " << chr;
                    }
                    int pos = atoi(tokens[2].c_str());
                    string markerName = string(tokens[1]);
                    char effectAllele = tokens[3][0];
                    char nonEffectAllele = tokens[4][0];
                    if (G.debugMode) cout << "Pos: " << pos << "\nmarker:" << markerName << "\nea/nea:" << effectAllele <<"/" << nonEffectAllele<<"\n";

                    vector <double> gen;
                    vector <double> gen2;
                    double fijeij = 0;                 //for info score
                    double aa=0; double aA=0; double AA=0;
                    double callrate=0; double ok_gen=0; double not_ok_gen=0;
                    double infoscore = 1;
                    int j = 0;
                    for (int i = 5; i < n; i+=3)
                    {
                        //determined
                        if(G.dosages==false)
                        {
                            if (S[j].isOK())
                            {
                                if (atof(tokens[i].c_str())>=.95){aa++;}
                                else if (atof(tokens[i+1].c_str())>=.95){aA++;}
                                else if (atof(tokens[i+2].c_str())>=.95){AA++;}
                            }
                            if (atof(tokens[i].c_str())>=.95){gen.push_back(2.0);ok_gen++;}
                            else if (atof(tokens[i+1].c_str())>=.95){gen.push_back(1.0);ok_gen++;}
                            else if (atof(tokens[i+2].c_str())>=.95){gen.push_back(0.0);ok_gen++;}
                            else {gen.push_back(-9999);not_ok_gen++;}
                        }
                        else
                        {
                            if (S[j].isOK())
                            {
                                aa+=atof(tokens[i].c_str());
                                aA+=atof(tokens[i+1].c_str());
                                AA+=atof(tokens[i+2].c_str());
                                double eij=(2*atof(tokens[i+2].c_str())) + atof(tokens[i+1].c_str());
                                double fij = (4*atof(tokens[i+2].c_str())) + atof(tokens[i+1].c_str());
                                fijeij+= fij - (eij*eij);
                            }
                            gen2.push_back(((atof(tokens[i+2].c_str())) + atof(tokens[i+1].c_str())));
                            gen.push_back(((atof(tokens[i].c_str())) + atof(tokens[i+1].c_str())));
                        }
                        if (n < i+5) i+=3;		//avoiding space in line end

                        j++;

                        //test if sample sizes match in genotype and sample file
                        int samplefile_n= (n -5)/3;
                        if (samplefile_n!=S.size())
                        {
                            cout << "The number of samples in genotype file (" << samplefile_n << ") does not match the number of samples in sample file (" << S.size() << "). Exit program!"<<endl;
                            exit (1);
                        }



                    }
                    if (G.debugMode)cout<<"aa,aA,AA"<< aa<<","<<aA<<","<<AA<<"\n";
                    if (G.dosages)
                    {
                        callrate=1;
                        double eaf = 0;
                        if (aa+aA+AA>0)
                        {
                            eaf = ((2*aa)+aA)/(2*(aa+aA+AA));

                        }
                        if (eaf==1 || eaf==0){infoscore=1;}
                        //info score calculation according to the measure in snptest:
                        //https://mathgen.stats.ox.ac.uk/genetics_software/snptest/snptest.v2.pdf
                        else
                        {
                            infoscore = 1-(fijeij/(2*(aa+aA+AA)*eaf*(1-eaf)));
                        }
                        if (G.debugMode)cout<<"N: " << n << " eaf: " << eaf << " aa+aA+AA: " << aa+aA+AA << " Infoscore: "<< infoscore<<endl;

                    }
                    else
                    {
                        callrate = ok_gen/(ok_gen+not_ok_gen);
                        if (G.debugMode)cout<<"Callrate: "<< callrate <<endl;
                    }

                    std::stringstream mrk2;
                    mrk2 << chr << ":" << pos;
                    string mrkname = mrk2.str();

                    bool markerExclusionInclusionIsOK=true;

                    if (G.markerExclusion)
                    {
                        if (G.excludemarkers[mrkname]){markerExclusionInclusionIsOK=false;}
                    }
                    if (G.markerExtraction)
                    {
                        if (!G.extractmarkers[mrkname]){markerExclusionInclusionIsOK=false;}
                    }

                    if (aa+aA+AA>0 && markerExclusionInclusionIsOK)
                    {
                        if (((2*aa)+aA)/(2*(aa+aA+AA))<=0.5)
                        {
                            marker m(markerName, effectAllele, nonEffectAllele, gen);
                            m.setMaf(((2*aa)+aA)/(2*(aa+aA+AA)));
                            if (pos>0 && chr>0 && chr<27 && G.rareVariantThreshold>=m.getMaf() && G.callrateThreshold<=callrate && G.infoThreshold<=infoscore && m.getMaf()>0)
                            {
                                m.setChromosome(chr);
                                m.setPosition(pos);
                                for (int zz=0; zz<GENE.size(); zz++)
                                {
                                    if (chr == GENE[zz].chr &&
                                        pos>= GENE[zz].start &&
                                        pos<=  GENE[zz].end)
                                    {
                                        GENE[zz].M.push_back(m);
                                    }
                                    else if (chr == GENE[zz].chr && pos>GENE[zz].end && GENE[zz].M.size()>0)
                                    {
                                        LOG << "Analysing genomic region " << zz+1 << " out of the total of " << GENE.size() << " regions." <<endl;
                                        Analyse(G, S, GENE[zz], LOG, ERR, OUT, BETAS);
                                        GENE[zz].M.clear();
                                    }
                                }
                                m_ok++;

                                if (G.debugMode)cout<<"Marker added to array with maf: "<< ((2*aa)+aA)/(2*(aa+aA+AA))<<"\n";
                                if (G.debugMode)cout<<"Rare allele: "<< effectAllele <<"\n";
                            }
                            else
                            {
                                m_notok++;
                                if (G.debugMode)cout<<"Marker not added\n";
                            }
                        }
                        else //i.e. if allele frequency for a>=0.5
                        {
                            for (unsigned int j = 0; j < gen.size(); j++)
                            {
                                if (!G.dosages){if (gen[j]==2){gen[j]=0;} else if (gen[j]==0){gen[j]=2;}}
                                else {gen[j] = gen2[j];}

                            } //turning around
                            marker m(markerName, nonEffectAllele, effectAllele, gen);
                            m.setMaf(((2*AA)+aA)/(2*(aa+aA+AA)));
                            if (pos>0 && chr>0 && chr<27 && G.rareVariantThreshold>=m.getMaf() && G.callrateThreshold<=callrate && G.infoThreshold<=infoscore && m.getMaf()>0)
                            {
                                m.setChromosome(chr);
                                m.setPosition(pos);

                                for (int zz=0; zz<GENE.size(); zz++)
                                {
                                    if (chr == GENE[zz].chr &&
                                        pos>= GENE[zz].start &&
                                        pos<=  GENE[zz].end)
                                    {
                                        GENE[zz].M.push_back(m);
                                    }
                                    else if (chr == GENE[zz].chr && pos>GENE[zz].end && GENE[zz].M.size()>0)
                                    {
                                        LOG << "Analysing genomic region " << zz+1 << " out of the total of " << GENE.size() << " regions." <<endl;
                                        Analyse(G, S, GENE[zz], LOG, ERR, OUT, BETAS);
                                        GENE[zz].M.clear();
                                    }
                                }

                                m_ok++;

                                if (G.debugMode)cout<<"Marker added to array with maf: "<< ((2*AA)+aA)/(2*(aa+aA+AA))<<"\n";
                                if (G.debugMode)cout<<"Rare allele: "<< nonEffectAllele <<"\n";
                            }
                            else
                            {
                                m_notok++;
                                if (G.debugMode)cout<<"Marker not added\n";
                            }
                        }
                    }
                }
            } //while loop
            for (int zz=0; zz<GENE.size(); zz++)
            {
                if (GENE[zz].M.size()>0)
                {
                    LOG << "Analysing genomic region " << zz+1 << " out of the total of " << GENE.size() << " regions." <<endl;
                    Analyse(G, S, GENE[zz], LOG, ERR, OUT, BETAS);
                    GENE[zz].M.clear();
                }
            }

        }
        else
        {
            cerr << "Error: Cannot find or access " << G.inputGenFile << ". Exit program." << endl;
            sprintf(sb, "E%.8d" , G.errNr); G.errNr++;
            LOG << "Error: Cannot find or access " << G.inputGenFile << ". Exit program! (" << sb << ")" <<endl;
            ERR << sb << " Error: Cannot find or access " << G.inputGenFile << ". Program exit!" <<endl;
            ERR << sb << " Error: Make sure that the file is in the given path and is readable." <<endl;
            return false;
        }
        return true;
    }//else (not gz file)
}

void Analyse(global & G, vector <sample> & S, gene & GENE_p, ofstream & LOG, ofstream & ERR, ofstream & OUT, ofstream & BETAS)
{


    int n = G.pheno_ok;


    vector<marker> M;
	double totalMAF =0;
    int count = 0;
    int count_all = 0;
    vector <std::string> marker_names;
    vector <double> marker_mafs;
    vector <double> genotype, weight;
    double bestModel = 1e200;
    string bestModelString = "";
    string bestBetasString = "";

    if (G.debugMode)cout << "Working on gene: "<< GENE_p.name << endl;

        M = GENE_p.M;

    for (unsigned int k = 0; k < S.size(); k++)
    {
        genotype.push_back(0);
        weight.push_back(0);
    }

    for (unsigned int j = 0; j < M.size(); j++)
    {
        if (M[j].getChromosome() == GENE_p.chr
            && M[j].getPosition() >= GENE_p.start
            && M[j].getPosition() <= GENE_p.end)
        {
            if (G.debugMode)cout << "Marker in region: "<< M[j].getName() << endl;
            if (G.debugMode)cout << "MAF (thresh): "<< M[j].getMaf() <<"("<<G.rareVariantThreshold<<")"<< endl;
            if (M[j].getMaf()<=G.rareVariantThreshold && M[j].getMaf()>0)
            {
                if (G.debugMode)cout << "MAF ok" << endl;
                for (unsigned int k = 0; k < S.size(); k++)
                {
                    if (!G.dosages)
                    {
                        if (M[j].getGenotype(k)>0)
                        {
                            if(!G.dosages)genotype[k]++;
                        }
                        else if(M[j].getGenotype(k)!=0)
                        {
                            weight[k]++; // we have missing phenotype
                        }
                    }
                    else
                    {
                        if (M[j].getGenotype(k)>=0)
                        {
                            genotype[k]+= M[j].getGenotype(k); //add dosage
                        }
                        else
                        {
                            weight[k]++;
                        }

                    }
                }
                count++;
                totalMAF+=M[j].getMaf();
                marker_names.push_back(M[j].getName());
                marker_mafs.push_back(M[j].getMaf());
            }
            count_all++;
        }
    }

    if (count>0)			//this gene has one or more markers with MAF below the cut-off
    {
        if (G.debugMode)cout << "Markers found: "<< count << endl;
        for (int l=0; l<marker_names.size(); l++){LOG << "Gene: " <<GENE_p.name << "\t" << "Marker: " <<marker_names[l]<<"\t" << "MAF: " << marker_mafs[l] <<endl; }

        double rareCount =0;  // number of rare alleles counted from all individuals

        unsigned int _rows=S.size(); //number of samples
        unsigned int _cols=(unsigned int)G.phenoList.size() + 2;
        if (G.debugMode) cout << "Mainmatrix x: " << _rows << " y: " << _cols << endl;

        matrixD _mainmatrix(_rows,_cols);

        for (unsigned int k = 0; k < S.size(); k++)
        {

                if ((count-weight[k])>0) {_mainmatrix.put(k,0,(double) genotype[k]/ (double)(count-weight[k]));} //Y
                else {_mainmatrix.put(k,0,0);}

                _mainmatrix.put(k,1,((count- weight[k])/count)); //weight

                    if(S[k].isOK())
                    {
                    rareCount += genotype[k];
                    }
                for (int j = 1; j<=G.phenoList.size(); j++)
                {


                    _mainmatrix.put(k,j+1,S[k].getPheno(j-1));
                }






        }


        //We have main table now - lets run through all possible combinations of phenotypes
        //if (G.debugMode)_mainmatrix.print();
                        int _testcount = pow(2,G.phenoList.size());
                        for (int test=_testcount-1; test>=1; test--)
                        {
                            int _phenoCount = 0;
                            int _sampleCount = 0;
                            vector<bool> phenoMask = phenoMasker(test,(int)G.phenoList.size());

                            if (G.debugMode)cout << "Current mask: ";
                            for (int i = 0; i < phenoMask.size(); i++)
                            {
                                if (phenoMask[i])
                                {
                                    _phenoCount++;
                                    if (G.debugMode)cout<<"1";
                                }
                                else{if (G.debugMode)cout<<"0";}
                            }
                            if (G.debugMode)cout << endl;

                            for (int i = 0; i<_mainmatrix.getRows(); i++)
                            {
                                bool indISOK = true;
                                if (G.debugMode){cout << S[i].getName();}

                                //genotype check: if any missing, IndISOK=false
                                if (_mainmatrix.get(i,0)==-9999){indISOK=false;}

                                //phenotypes check: if any missing, indISOK=false
                                for (int j = 1; j<_mainmatrix.getCols()-1; j++)
                                {

                                    if (phenoMask[j-1]){

                                        if (_mainmatrix.get(i,j+1)==-9999){indISOK=false;}
                                    }
                                    if (G.debugMode){cout << " " << _mainmatrix.get(i,j+1);}
                                }
/*
                                //covariate check: if covariates used and if any missing: then indISOK=false
                                if(G.covCount>0)
                                {
                                    for (int m=0; m<G.covCount; m++)
                                    {
                                            if (S[i].getCovariate(m)==-9999){indISOK=false;}

                                    }
                                }
*/
                                if (G.debugMode){cout << endl;}
                                if (indISOK)_sampleCount++;
                            }
                            if (G.debugMode)cout <<"size: " << G.phenoList.size()<< "test: " << test << " indcount: " << _sampleCount << " phenocount: " <<   _phenoCount << endl;
                            arrayD *Y = new arrayD ( _sampleCount );
                            matrixD *X = new matrixD ( _sampleCount, _phenoCount+1); //matrixD *X = new matrixD ( _sampleCount, _phenoCount+G.covCount+1);
                            arrayD *W = new arrayD ( _sampleCount );
                            int curInd = 0;
                            vector <double> COPYpheno;
                            for (int i = 0; i<_mainmatrix.getRows(); i++)
                            {
                                bool indISOK = true;
                                if (_mainmatrix.get(i,0)==-9999){indISOK=false;}
                                for (int j = 1; j<_mainmatrix.getCols()-1; j++)
                                {

                                    if (phenoMask[j-1]){

                                        if (_mainmatrix.get(i,j+1)==-9999){indISOK=false;}
                                    }
                                }

                                /*if(G.covCount>0)
                                {
                                    for (int m=0; m<G.covCount; m++)
                                    {
                                            if (S[i].getCovariate(m)==-9999){indISOK=false;}

                                    }
                                }*/



                                if (indISOK)
                                {
                                    int z=1;

                                    //genotype
                                    Y->put(curInd, _mainmatrix.get(i,0));

                                    COPYpheno.push_back(_mainmatrix.get(i,0));

                                    W->put(curInd,_mainmatrix.get(i,1));
                                    X->put(curInd, 0,  1.0);

                                    for (int j = 1; j<_mainmatrix.getCols()-1; j++)
                                    {
                                        if (phenoMask[j-1])
                                        {
                                            X->put(curInd, z, _mainmatrix.get(i,j+1));

                                            if (G.debugMode) {cout << " " << X->get(curInd,z);}
                                            z++;
                                        }
                                    }

                                    /*int cc=G.covCount;
                                    if(cc>0){
                                    for (int k = 0; k < G.covCount; k++) //add covariates in X after the phenotypes
                                    {
                                        X->put(curInd, _phenoCount+k+1, S[i].getCovariate(k));


                                        if (G.debugMode) {cout << " " << X->get(curInd,_phenoCount+k+1);}

                                    }

                                    }//if */
                                    if (G.debugMode){cout << endl;}
                                    curInd++;

                                }
                            }

                            lr LR;
                            try {
                                if (LR.lr_w(Y, X, W) && test!=_testcount)
                                {
                                    matrixD * C = LR.covariance;
                                    C->InvertS();
                                    double x;
                                    for (int i=0; i<(unsigned int) _phenoCount;i++)
                                        for (int j=0; j<(unsigned int) _phenoCount;j++)
                                            x+=LR.Cstat->get(i)*LR.Cstat->get(j)*C->get(i,j);
                                    double testLogLikelihood = -LR.getLnLk(Y, X, W)/2;
                                    double nullLogLikelihood = -LR.nullLikelihood(COPYpheno)/2;
                                    if (G.debugMode){cout << "Linear regression done with model: " << test << endl;}


                                    for (int k = 0; k<=_phenoCount;k++)
                                    {
                                        double _pPheno = (1-studenttdistribution((_sampleCount*2) - _phenoCount,ddabs(LR.Cstat->get(k)/LR.SECstat->get(k))))*2;
                                        if (G.debugMode){cout << k << "\t" << (_sampleCount*2) << "\t" << _phenoCount << "\t" << LR.Cstat->get(k) <<  "\t" << LR.SECstat->get(k) << "\t" << _pPheno << endl;}

                                    }
                                    double likelihoodRatio = 2 * (testLogLikelihood - nullLogLikelihood);
                                    double _BIC = (-2 * testLogLikelihood) + ((_phenoCount+1) * log(_sampleCount));
                                    double _BICnull = (-2 *nullLogLikelihood) + (log(_sampleCount));

                                    double _pModel;
                                    if (ddabs(likelihoodRatio)>0){_pModel = 1-chisquaredistribution(_phenoCount,ddabs(likelihoodRatio));}
                                    else {_pModel = NAN;}

                                    if (G.debugMode){cout << "Likelihood: " << testLogLikelihood << endl;}
                                    if (G.debugMode){cout << "nullLikelihood: " << nullLogLikelihood << endl;}
                                    if (G.debugMode){cout << "Model likelihood ratio: " << likelihoodRatio << endl;}
                                    if (G.debugMode){cout << "Model p: " << _pModel << endl;}



                                    std::stringstream line, line2;
                                    if (_BIC < bestModel)
                                    {


                                        line << GENE_p.name << "\t" << count <<"\t" << _sampleCount << "\t" << rareCount << "\t" << totalMAF << "\t" << totalMAF/count << "\t";
                                        line << "\t" << _phenoCount << "\t";
                                        for (int i = 0; i < phenoMask.size(); i++) {if (phenoMask[i]){line<<"1";}else{line<<"0";}}
                                        line << "\t" << testLogLikelihood<<  "\t" <<  nullLogLikelihood <<
                                        "\t" << likelihoodRatio << "\t" << _pModel << "\t" << _BIC << "\t" << _BICnull << "\t";

                                        vector<string> phenosorter;
                                        for (int i = 0; i < phenoMask.size(); i++){if(phenoMask[i])phenosorter.push_back(G.phenoList[i]);}
                                        bool phenostart = true;
                                        for (int i = 0; i < phenosorter.size(); i++) {if (phenostart){line<<phenosorter[i];phenostart=false;}else{line << "+" <<phenosorter[i];}}
                                        line << "\t";
                                        sort(phenosorter.begin(),phenosorter.end());
                                        phenostart = true;
                                        for (int i = 0; i < phenosorter.size(); i++) {if (phenostart){line<<phenosorter[i];phenostart=false;}else{line << "+" <<phenosorter[i];}}

                                        if (G.printCovariance)
                                        {
                                            for (int i = 1; i < LR.Cstat->size() ;i++) line << "\t" << LR.Cstat->get(i) << "\t" <<LR.SECstat->get(i);
                                            for (int i = 1; i < LR.Cstat->size();i++)
                                            {
                                                for (int j = i; j < LR.Cstat->size();j++)
                                                    line << "\t" << LR.covariance->get(i,j);
                                            }
                                        }
                                        line << endl;
                                        bestModelString = line.str();

                                        int k=1;
                                        for (int i = 0; i < phenoMask.size(); i++)
                                        {
                                            if (phenoMask[i])
                                            {

                                                line2 << GENE_p.name << "\t" << count <<"\t" << _sampleCount << "\t" << rareCount << "\t" << totalMAF << "\t" << totalMAF/count << "\t";
                                                bool phenostart = true;
                                                for (int j = 0; j < phenoMask.size(); j++)
                                                {
                                                    if (phenoMask[j] && phenostart)
                                                    {
                                                        line2<<G.phenoList[j];
                                                        phenostart=false;
                                                    }
                                                    else if(phenoMask[j])
                                                    {
                                                        line2 << "+" <<G.phenoList[j];
                                                    }
                                                }
                                                line2  << "\t" << G.phenoList[i] << "\t" << LR.Cstat->get(k) << "\t" << LR.SECstat->get(k) << endl;
                                                k++;
                                            }
                                        }
                                        bestBetasString = line2.str();
                                        bestModel = _BIC;
                                    }
                                    if (G.printAll || G.printComplex)
                                    {


                                        OUT << GENE_p.name << "\t" << count <<"\t" << _sampleCount << "\t" << rareCount << "\t" << totalMAF << "\t" << totalMAF/count << "\t";
                                        OUT << "\t" << _phenoCount << "\t";
                                        for (int i = 0; i < phenoMask.size(); i++) {if (phenoMask[i]){OUT<<"1";}else{OUT<<"0";}}
                                        OUT << "\t" << testLogLikelihood <<  "\t" <<  nullLogLikelihood <<
                                        "\t" << likelihoodRatio << "\t" << _pModel << "\t" << _BIC << "\t" << _BICnull << "\t";

                                        vector<string> phenosorter;
                                        for (int i = 0; i < phenoMask.size(); i++){if(phenoMask[i])phenosorter.push_back(G.phenoList[i]);}
                                        bool phenostart = true;
                                        for (int i = 0; i < phenosorter.size(); i++) {if (phenostart){OUT<<phenosorter[i];phenostart=false;}else{OUT << "+" <<phenosorter[i];}}
                                        OUT << "\t";
                                        sort(phenosorter.begin(),phenosorter.end());
                                        phenostart = true;

                                        for (int i = 0; i < phenosorter.size(); i++) {if (phenostart){OUT<<phenosorter[i];phenostart=false;}else{OUT << "+" <<phenosorter[i];}}

                                        if (G.printCovariance)
                                        {
                                            for (int i = 1; i < LR.Cstat->size() ;i++) OUT << "\t" << LR.Cstat->get(i) << "\t" <<LR.SECstat->get(i);
                                            for (int i = 1; i < LR.Cstat->size();i++)
                                            {
                                                for (int j = i; j < LR.Cstat->size();j++)
                                                    OUT << "\t" << LR.covariance->get(i,j);
                                            }
                                        }
                                        OUT << endl;
                                        int k=1;
                                        for (int i = 0; i < phenoMask.size(); i++)
                                        {
                                            if (phenoMask[i])
                                            {
                                                if (G.printBetas) BETAS << GENE_p.name << "\t" << count <<"\t" << _sampleCount << "\t" << rareCount << "\t" << totalMAF << "\t" << totalMAF/count << "\t";
                                                bool phenostart = true;
                                                for (int j = 0; j < phenoMask.size(); j++)
                                                {
                                                    if (phenoMask[j] && phenostart)
                                                    {
                                                        if (G.printBetas) BETAS<<G.phenoList[j];
                                                        phenostart=false;
                                                    }
                                                    else if(phenoMask[j])
                                                    {
                                                        if (G.printBetas) BETAS << "+" <<G.phenoList[j];
                                                    }
                                                }
                                                if (G.printBetas) BETAS  << "\t" << G.phenoList[i] << "\t" << LR.Cstat->get(k) << "\t" << LR.SECstat->get(k) << endl;
                                                k++;
                                            }
                                        }
                                    }


                               } //if(LR.lr_w())
                              else
                                 {

                                    if (test!=_testcount) LOG << "Collinearity problem with model: " << GENE_p.name << "\t" << test << " " << _testcount << " ";
                                    bool phenostart = true;
                                    for (int i = 0; i < phenoMask.size(); i++) {if (phenoMask[i] && phenostart){LOG<<G.phenoList[i];phenostart=false;}else if(phenoMask[i]){LOG << "+" <<G.phenoList[i];}}
                                    LOG << endl;
                                }

                            } catch (ArgException &e)  // catch any exceptions
                            { cerr << "error: " << e.error() << " for linear model " << e.argId() << endl; }
                            delete X;
                            delete Y;
                            delete W;
                            if (G.printComplex){break;}



          }//for test

          if (!G.printAll && !G.printComplex)
                        {
                            if (G.printBetas)BETAS << bestBetasString;
                            OUT << bestModelString;
                        }

        genotype.clear();
        weight.clear();

        } //if (count>0)

} //Analyse
